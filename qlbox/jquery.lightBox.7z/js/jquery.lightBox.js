/*!
 * Base On jQuery JavaScript Library v1.4.2
 * http://jquery.com/
 * Libs:Jay lightBox
 * Copyright 2012, QinLiang
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * Date: 2012.10.22
 */

(function($){  
	lightBox={
		defaults: {
			model:true,
			hasClose:true		
		}
	}
	Defaults=lightBox.defaults;
	function LightBox(root,defaults){
		var self=this,
			boxObj=root;
		
		$.extend(this,{
			setModel:function(){
				var modelHtml="<div id='boxModel'></div>",
					wW=$(window).width(),
				 	bH=$("body").height();
				$("body").append(modelHtml);
				$("#boxModel").width(wW);
				$("#boxModel").height(bH); 
				$("#boxModel").css("opacity",0.5).show();
			},
			setPosition:function(){
				var wW=$(window).width(),
					wH=$(window).height(),
					wScrollTop=$(window).scrollTop(),
					bW=boxObj.width(),
					bH=boxObj.height(),
					bLeft=(wW-bW)/2,
					bTop=(wH-bH)/2+wScrollTop;
				return [bLeft,bTop];
				
			},
			setClose:function(){
				var closeObj="<a class='closeBtn' href='#'>关闭</a>";
				boxObj.append(closeObj);
				$(".closeBtn").live("click",function(){
					boxObj.hide();
					$("#boxModel").remove();
					return false;	
				})	
			}
		})
		Defaults.model?self.setModel():"";
		Defaults.hasClose?self.setClose():"";
		var p=self.setPosition();
		boxObj.css({"left":p[0]+"px","top":p[1]+"px"}).show();
			
	
	}


	$.fn.lightBox = function(defaults){
		var o=$.extend(Defaults,defaults);		
		return this.each(function(){
			el = new LightBox($(this), defaults);
		})

	}
})(jQuery);